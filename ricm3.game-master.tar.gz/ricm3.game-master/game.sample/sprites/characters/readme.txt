These guys are intended to be used with the guns overlaid on top of them (in their hands).

The "south2" pose is a normal walking animation without the arms holding the gun.