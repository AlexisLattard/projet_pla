package edu.ricm3.game.tomatower;

import java.awt.Graphics;

public class Weapon {
	Model model;
	int range;
	int power;
	int direction;
	
	public Weapon() {
		
	}
	
	public void paint(Graphics g, int x, int y) {
		
	}
	
	public void hit(int origin_cell_x, int origin_cell_y) {
		
	}
	
	

}
