package edu.ricm3.game.tomatower;

public enum ObstaclesKind {
	Stone,
	Tree,
	Lake
}
