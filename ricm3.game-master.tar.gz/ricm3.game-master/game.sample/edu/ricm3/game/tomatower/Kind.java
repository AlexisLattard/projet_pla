package edu.ricm3.game.tomatower;

public enum Kind {
	Team,
	Ennemis,
	Nothing,
	Obstacle,
	Unknwon,
	Any
}
