package edu.ricm3.game.tomatower.automaton;


import edu.ricm3.game.tomatower.entities.enums.Kind;

public class A_EntityParameter extends A_Parameter{
	Kind value;
	
	public A_EntityParameter(Kind v) {
		this.value = v;
	}
}
