package edu.ricm3.game.tomatower.automaton;

public class A_KeyParameter extends A_Parameter {
	
	String value;
	
	public A_KeyParameter(String v) {
		this.value = v;
	}

}
