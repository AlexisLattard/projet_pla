package edu.ricm3.game.tomatower.entities.enums;

public enum Kind {
	Team,
	Ennemis,
	Nothing,
	Obstacle,
	Unknwon,
	Gate,
	Takable,
	Void
}