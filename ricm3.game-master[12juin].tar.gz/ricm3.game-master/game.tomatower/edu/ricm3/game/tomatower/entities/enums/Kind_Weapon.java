package edu.ricm3.game.tomatower.entities.enums;

public enum Kind_Weapon {
	Red,
	Blue,
	Yellow,
	Purple
}
