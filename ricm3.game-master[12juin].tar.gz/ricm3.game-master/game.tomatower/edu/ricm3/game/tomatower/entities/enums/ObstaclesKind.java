package edu.ricm3.game.tomatower.entities.enums;

public enum ObstaclesKind {
    Stone,
    Tree,
    Lake,
    PORTAL_TO_CHALLENGE,
    PORTAL_TO_STORE,
    PORTAL_TO_GAME,
    PORTAL_DESTINATION,
    CRYSTAL,
    UPGRADE,
    PRODUCT
}